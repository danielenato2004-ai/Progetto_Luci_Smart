/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dma.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"
#include "stdio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

// =================================================================
// VARIABILI DI ACCENZIONE
// =================================================================

// 'volatile' perchè la memoria è modificata dal DMA in background, senza CPU
volatile uint16_t adc_values[2];           // Vettore a 2 canali stabili a 84 cicli: [0] = Luce, [1] = Potenziometro

volatile uint8_t sistema_acceso = 1;       // Stato logico della lampada: 1 = attiva, 0 = spenta in sonno
volatile uint8_t mode_active = 0;          // Selezione operativa: 0 = AUTOMATICO, 1 = MANUALE

volatile uint8_t flag_leggi_adc = 0;       // Diventa 1 ogni 15 secondi esatti grazie al TIM3
volatile uint8_t flag_bottone_premuto = 0; // Diventa 1 nell'istante esatto in cui premi il tasto PC13


// =================================================================
// SLEEP CON MONITORAGGIO LUCE
// =================================================================
volatile uint8_t modo_sleep_attivo = 0;  // 1 = Il sistema è in sleep ma ascolta il timer (CPU in stop)
uint16_t valore_luce_pre_sleep = 0;      // Registra il valore prima di dormire
#define SOGLIA_SVEGLIA_LUCE    150       // Valore della "forte variazione"
// =================================================================

// ==============
// MANUALE
// ==============
uint16_t prev_pot = 0;           // Memorizza l'ultimo valore del potenziometro
uint32_t manual_timestamp = 0;   // Salva il millisecondo in cui è avvenuto l'ultimo movimento
uint32_t sync_timestamp = 0;     // Gestiste la finestra dei 200ms
uint8_t final_value_printed = 1; // Flag per inviare il messaggio di fine movimento UNA sola volta
#define POT_THRESHOLD  300       // Soglia di variazione, per evitare il rumore dell'ADC

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

void RestoreClockAfterStopMode(void);

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

char buffertx[100];                   // Buffer UART maggiorato per il debug.
uint32_t pwm_value = 0;               // MODIFICATO IN uint32_t: Il Timer 2 lavora a 32-bit!

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_ADC1_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_USART2_UART_Init();
  /* USER CODE BEGIN 2 */

  // 1. Avviamo le periferiche una volta sola all'avvio!
  HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);   // Attiva il PWM del TIM2 per pilotare la luminosità del led
  HAL_TIM_Base_Start_IT(&htim3);              // Avvia il TIM3 con interrupt attivo (15s)

  // 2. Avvia il DMA dell'ADC per aggiornare continuamente 'adc_values'
  HAL_ADC_Start_DMA(&hadc1, (uint32_t*)adc_values, 2);

  // 3. Aspetta che l'ADC faccia la primissima lettura e allinea i valori
  HAL_Delay(50);
  prev_pot = adc_values[1];        // Scatta la foto iniziale al potenziometro
  final_value_printed = 1;         // Protegge dal Flooding
  mode_active = 0;                 // Forza la partenza in AUTOMATICO
  sistema_acceso = 1;
  flag_leggi_adc = 1;              // Forza la prima lettura della luce

  // --- STRATEGIA ANTI-FLOODING ---
  // Diciamo al DMA di lavorare in silenzio. Aggiornerà la RAM in background
  extern DMA_HandleTypeDef hdma_adc1;  // Ponte di collegamento tra gli altri file
  __HAL_DMA_DISABLE_IT(&hdma_adc1, DMA_IT_TC | DMA_IT_HT);

  // PULIZIA REGISTRO ADC: Cancella l'eventuale flag di Overrun iniziale
  __HAL_ADC_CLEAR_FLAG(&hadc1, ADC_FLAG_OVR);

  // 2. ASSICURIAMO L'AVVIO: Pulizia da falsi interrupt elettrici all'accensione
  HAL_Delay(100);
  flag_bottone_premuto = 0;
  sistema_acceso = 1;
  mode_active = 0;       // <--- FORZA MODALITÀ AUTOMATICA ALL'AVVIO
  flag_leggi_adc = 1;    // <--- Richiedi subito la stampa del sensore automatico
  __HAL_GPIO_EXTI_CLEAR_IT(GPIO_PIN_13);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

	  // =================================================================
	  // CASO A: IL SISTEMA È IN MODALITÀ SLEEP (Isolamento Totale)
	  // =================================================================
	  if (modo_sleep_attivo == 1)
	  {
		  // 1. Spegniamo il SysTick prima di dormire, così eviti che si svegli ogni 1ms
		  HAL_SuspendTick();

		  // 2. La CPU dorme, ma i Timer e il DMA restano accesi in background

		  HAL_PWR_EnterSLEEPMode(PWR_MAINREGULATOR_ON, PWR_SLEEPENTRY_WFI);

		  // -----------------------------------------------------------------
		  // PUNTO DI RISVEGLIO: La CPU riprende l'esecuzione da qui dopo un interrupt valido
		  // -----------------------------------------------------------------

		  // 3. Riattiva SUBITO il SysTick per usare correttamente i delay
		  HAL_ResumeTick();

		  // ------ VERIFICA RISVEGLIO ------//

		  // --- CONTROLLO RISVEGLIO 1: PRESSIONE DEL PULSANTE FISICO (PC13) ---
		  if (flag_bottone_premuto == 1)
		  {
			  flag_bottone_premuto = 0;              // Reset immediato del flag
			  __HAL_GPIO_EXTI_CLEAR_IT(GPIO_PIN_13); // Pulisce i falsi contatti hardware

			  HAL_Delay(40); // Filtro antirumore (debounce)
			  if (HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_13) == GPIO_PIN_RESET)
			  {
				  // FONDAMENTALE: Blocca il codice finché l'utente non TOGLIE il dito dal bottone!
				  // Impedisce al sistema di interpretare il rilascio come un comando successivo.
				  while(HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_13) == GPIO_PIN_RESET);
				  HAL_Delay(40); // Debounce al rilascio

				  // Sveglia totale e configurazione pulita per la modalità AUTO
				  modo_sleep_attivo = 0;     // Disattiva l'isolamento energetico
				  sistema_acceso = 1;        // Riaccende
				  mode_active = 0;           // Forza il sistema in AUTOMATICO
				  flag_leggi_adc = 1;        // Richiedi subito la lettura del sensore luce
				  prev_pot = adc_values[1];  // Sincronizza il valore del potenziometro
				  final_value_printed = 1;
				  flag_bottone_premuto = 0;  // Sicurezza extra

				  // Comunicazione tramite seriale tramite risveglio
				  int len = sprintf(buffertx, "SISTEMA: RIATTIVATO | Pulsante premuto\r\n");
				  HAL_UART_Transmit(&huart2, (uint8_t*)buffertx, len, 100);

				  continue; // Salta lo logica dello sleep e ritorna al while(1)
				  }
		  }

		  // --- CONTROLLO RISVEGLIO 2: SCATTO DEI 15 SECONDI DEL TIM3 (VARIAZIONE LUCE) ---
		  if (flag_leggi_adc == 1)
		  {
			  flag_leggi_adc = 0; // Resetta il flag del timer

			  uint16_t valore_attuale_luce = adc_values[0];  // Recupera il valore aggiornato in background dal DMA

			  //Sensore invertito: passando dal giorno alla notte il valore sale.
			  // Calcoliamo la quantità di oscurità aggiuntiva rispetto a quando siamo andati in sleep.
			  int32_t aumento_oscurità = (int32_t)valore_attuale_luce - (int32_t)valore_luce_pre_sleep;

			  // ==========================================
			  // Stampa diagnostica inviata via UART per monitorare i calcoli eseguiti dalla CPU
			  int len_db = sprintf(buffertx, "SISTEMA: SLEEP | Risparmio Energetico: 100%%\r\n");
			  HAL_UART_Transmit(&huart2, (uint8_t*)buffertx, len_db, 100);
			  // ==========================================

			  // Sveglia il sistema se si è superato una certa soglia
			  if (aumento_oscurità > SOGLIA_SVEGLIA_LUCE)
			  {
				  modo_sleep_attivo = 0;    // Sveglia il sistema
				  sistema_acceso = 1;       // Ripristina l'operatività
				  mode_active = 0;          // Forza AUTOMATICO
				  flag_leggi_adc = 1;       // Ricalcolo della luce
				  prev_pot = adc_values[1];
				  final_value_printed = 1;
				  flag_bottone_premuto = 0;  // Pulisce eventuali disturbi elettrici accumulati

				  int len = sprintf(buffertx, "SISTEMA: RIATTIVATO | Rilevato abbassamento di luce.\r\n");
				  HAL_UART_Transmit(&huart2, (uint8_t*)buffertx, len, 100);

				  continue;    // Esce dallo sleep  e torna nel ciclo
			  }
		  }

		  // Se l'interrupt era solo un disturbo di linea o la luce non è cambiata abbastanza,
		  // il 'continue' interrompe il codice, rispegne il SysTick e rimette subito a dormire la CPU.
		  continue;
	  }

	  // =================================================================
	  // CASO B: IL SISTEMA È ACCESO (Logica di funzionamento Standard)
	  // =================================================================

	  // =================================================================
	  // LOGICA DI INGRESSO IN SLEEP AUTOMATICO (Nel ciclo attivo)
	  // =================================================================
	  if (modo_sleep_attivo == 0 && sistema_acceso == 1 && mode_active == 0)
	  {
		  // Se il sensore vede giorno (valore vicino allo 0, impostiamo sotto 200)
		  if (adc_values[0] > 0 && adc_values[0] < 150)
		  {
			  // 1. Salva la luminosità attuale come "punto di riferimento"
			  valore_luce_pre_sleep = adc_values[0];

			  // 2. Spegne completamente il LED e azzera il Duty Cycle del PWM gestito da TIM2
			  __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, 0);


			  // 3. Attiva i flag per mandare il sistema in sonno al prossimo ciclo
			  modo_sleep_attivo = 1;   // Al prossimo ciclo sarà in sleep
			  sistema_acceso = 0;      // Disattiva la logica principale

			  int len = sprintf(buffertx, "SISTEMA: SLEEP | Elevata luce esterna | Risparmio Energetico 100%% \r\n");
			  HAL_UART_Transmit(&huart2, (uint8_t*)buffertx, len, 100);

			  continue; // Salta il resto del codice e va direttamente nel blocco Sleep
			  }
	  }

	  // ===============================================================
	  // Modalità AUTOMATICA e MANUALE
	  // =================================================================

	  if (sistema_acceso == 1)
	  {
		  // 1. GESTIONE PULSANTE PER ENTRARE IN SLEEP
		  if (flag_bottone_premuto == 1)
		  {
			  flag_bottone_premuto = 0; // Reset immediato
			  __HAL_GPIO_EXTI_CLEAR_IT(GPIO_PIN_13);

			  HAL_Delay(40); // Filtro debounce (ignora le false attivazioni dovute al rumore del potenziometro)
			  if (HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_13) == GPIO_PIN_RESET)
			  {
				  // Aspetta il rilascio completo prima di andare a dormire
				  while(HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_13) == GPIO_PIN_RESET);
				  HAL_Delay(40);

				  valore_luce_pre_sleep = adc_values[0]; // Salva lo stato luminoso attuale
				  sistema_acceso = 0;
				  modo_sleep_attivo = 1;                 // Sposta lo stato del sistema in Sleep

				  __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, 0); // Spegne fisicamente il LED

				  int len = sprintf(buffertx, "SISTEMA: SLEEP | Pulsante Premuto | Risparmio Energetico 100%% \r\n", valore_luce_pre_sleep);
				  HAL_UART_Transmit(&huart2, (uint8_t*)buffertx, len, 100);

				  continue; // Forza il salto immediato nel blocco di sleep protetto
				  }
		  }

		  // 2. LOGICA MODALITÀ CON OVERRIDE MANUALE (SOGLIA 150)
		  uint16_t current_pot = adc_values[1];
		  int32_t variazione = (int32_t)current_pot - (int32_t)prev_pot;
		  if (variazione < 0) variazione = -variazione;

		  // SE L'UTENTE MUOVE IL POTENZIOMETRO
		  if (variazione > 300)
		  {
			  if (mode_active == 0)
			  {
				  mode_active = 1;
				  int len = sprintf(buffertx, "SISTEMA: MANUALE | Variazione Manopola.\r\n");
				  HAL_UART_Transmit(&huart2, (uint8_t*)buffertx, len, 100);
			  }
			  manual_timestamp = HAL_GetTick();  // Orologio interno, segna i ms da quando la scheda è stata accesa o resettata
			  final_value_printed = 0;
			  prev_pot = current_pot;

			  uint32_t timer_arr = htim2.Instance->ARR;  // Legge il Counter Period del TIM2
			  if (timer_arr == 0) timer_arr = 255;       // Evita bug fatale (divisiona per zero)
			  pwm_value = (uint32_t)(((uint64_t)current_pot * timer_arr) / 4095);
			  __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, pwm_value);   // Per cambiare valore del PWM in tempo reale
		  }

		  // SE SIAMO IN MODALITÀ MANUALE (Attesa stabilizzazione o Timeout)
		  if (mode_active == 1)
		  {

			  // Sistema Anti_flooding
			  if (final_value_printed == 0 && (HAL_GetTick() - manual_timestamp >= 1000))
			  {
				  final_value_printed = 1;   // Attivo "lucchetto"

				  uint32_t timer_arr = htim2.Instance->ARR;
				  if (timer_arr == 0) timer_arr = 255;
				  uint32_t imposta_pct = (pwm_value * 100) / timer_arr;
				  uint32_t risparmio_pct = 100 - imposta_pct;

				  int len = sprintf(buffertx, "SISTEMA: MANUALE | Luminosità: %lu%% | Risparmio Energetico: %lu%%\r\n", imposta_pct, risparmio_pct);
				  HAL_UART_Transmit(&huart2, (uint8_t*)buffertx, len, 100);
			  }

			  if (HAL_GetTick() - manual_timestamp >= 30000)
			  {
				  mode_active = 0;
				  flag_leggi_adc = 1;      // Forza lettura immediata della fotoresistenza
				  final_value_printed = 1; // Attivo "lucchetto"

				  int len = sprintf(buffertx, "SISTEMA: AUTOMATICO | TIMEOUT scaduto.\r\n");
				  HAL_UART_Transmit(&huart2, (uint8_t*)buffertx, len, 100);

				  prev_pot = adc_values[1];
			  }
		  }

		  // LOGICA MODALITÀ AUTOMATICA (Eseguita ogni 15s se mode_active è 0)
		  if (mode_active == 0)
		  {
			  // Aggiornamento Valori Potenziometro
			  if (HAL_GetTick() - sync_timestamp >= 200)
			  {
				  sync_timestamp = HAL_GetTick();
				  prev_pot = current_pot;
			  }


			  if (flag_leggi_adc == 1)
			  {
				  flag_leggi_adc = 0;
				  uint16_t sensore = adc_values[0];
				  prev_pot = adc_values[1];

				  uint32_t timer_arr = htim2.Instance->ARR;
				  if (timer_arr == 0) timer_arr = 255;
				  pwm_value = (uint32_t)(((uint64_t)sensore * timer_arr) / 4095);

				  __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, pwm_value);

				  uint32_t intensita_lampada_pct = (pwm_value * 100) / timer_arr;
				  uint32_t risparmio_pct = 100 - intensita_lampada_pct;

				  int len = sprintf(buffertx, "SISTEMA: AUTOMATICO | Luminosità: %lu%% | Risparmio Energetico: %lu%%\r\n", intensita_lampada_pct, risparmio_pct);
				  HAL_UART_Transmit(&huart2, (uint8_t*)buffertx, len, 100);
			  }
		  }
	  }

  /* USER CODE END 3 */
}
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE2);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

void RestoreClockAfterStopMode(void)
  {
	// 1. Riabilita il Power Clock e la configurazione del regolatore
	__HAL_RCC_PWR_CLK_ENABLE();
	__HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE2);

	// 2. Riaccendi il PLL (che si era spento in STOP mode)
	__HAL_RCC_PLL_ENABLE();

	// 3. Attendi che il PLL sia stabile e pronto
	while(__HAL_RCC_GET_FLAG(RCC_FLAG_PLLRDY) == RESET);

	// 4. Seleziona il PLL come sorgente del clock di sistema
	__HAL_RCC_SYSCLK_CONFIG(RCC_SYSCLKSOURCE_PLLCLK);

	// 5. Attendi che lo switch del clock sia completato
	while(__HAL_RCC_GET_SYSCLK_SOURCE() != RCC_SYSCLKSOURCE_STATUS_PLLCLK);
  }

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
